package littlebreadloaf.bleachreborn.items;

import net.minecraft.item.Item;

public class ItemArrancarEssence extends Item {

}
