package littlebreadloaf.bleachreborn.tiles;

import net.minecraft.tileentity.*;

public class TileLantern extends TileEntity
{
    public void updateEntity() {
        super.updateEntity();
    }
}
