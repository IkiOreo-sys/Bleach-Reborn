package littlebreadloaf.bleachreborn.tiles;

import net.minecraft.tileentity.*;

public class TileGraveStone extends TileEntity
{
}
