package littlebreadloaf.bleachreborn;

public class BleachModInfo
{
    public static final String ID = "bleachreborn";
    public static final String NAME = "Bleach Mod";
    public static final String VERSION = "2.0.7";
    public static final String CHANNEL = "bleachreborn";
    public static final String PROXY_LOCATION = "littlebreadloaf.bleachreborn.proxies";
}
