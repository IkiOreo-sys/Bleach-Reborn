package xyz.ashleyz.factions;

public class FactionTypes {
}
