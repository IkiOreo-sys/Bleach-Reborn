package xyz.ashleyz.factions;

public class HollowFaction extends Faction {
    HollowFaction() {
        super();
    }
    
    @Override
    public int getId() {
        return 3;
    }
    
    @Override
    public String getName() {
        return "Hollow";
    }
}
